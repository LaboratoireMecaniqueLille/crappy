Command and Real-time Acquisition in Parallelized PYthon (CRAPPY)
=======================

This package aims to provide easy-to-use tools for command and acquisition on complex experimental setups.

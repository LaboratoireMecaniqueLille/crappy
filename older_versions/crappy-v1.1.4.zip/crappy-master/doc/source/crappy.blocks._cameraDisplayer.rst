CameraDisplayer
=====================================

.. automodule:: crappy.blocks._cameraDisplayer
    :members:
    :show-inheritance:

Agilent34420ASensor
=========================================

.. automodule:: crappy.sensor._Agilent34420ASensor
    :members:
    :undoc-members:

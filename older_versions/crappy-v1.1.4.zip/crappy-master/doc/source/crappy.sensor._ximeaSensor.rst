XimeaSensor
=================================

.. automodule:: crappy.sensor._ximeaSensor
    :members:
    :undoc-members:
    :show-inheritance:
ComediActuator
======================================

.. automodule:: crappy.actuator._comediActuator
    :members:
    :undoc-members:

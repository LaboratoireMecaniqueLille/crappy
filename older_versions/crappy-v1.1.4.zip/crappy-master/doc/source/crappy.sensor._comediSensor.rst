ComediSensor
==================================

.. automodule:: crappy.sensor._comediSensor
    :members:
    :undoc-members:

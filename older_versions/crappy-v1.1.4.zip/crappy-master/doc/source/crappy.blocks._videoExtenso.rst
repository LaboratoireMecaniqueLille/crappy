VideoExtenso
==================================

.. automodule:: crappy.blocks._videoExtenso
    :members:
    :show-inheritance:

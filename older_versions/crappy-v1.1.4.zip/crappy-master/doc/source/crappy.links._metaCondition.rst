MetaCondition
==================================

.. automodule:: crappy.links._metaCondition
    :members:

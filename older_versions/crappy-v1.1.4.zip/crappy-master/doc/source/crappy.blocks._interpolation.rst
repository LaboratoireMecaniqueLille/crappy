Interpolation
===================================

.. automodule:: crappy.blocks._interpolation
    :members:
    :show-inheritance:

BiotensSensor
===================================

.. automodule:: crappy.sensor._biotensSensor
    :members:
    :undoc-members:

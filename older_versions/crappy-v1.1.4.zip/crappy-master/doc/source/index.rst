.. crappy documentation master file, created by
   sphinx-quickstart on Tue Feb 16 13:04:19 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to crappy's documentation!
==================================

.. toctree::
   :maxdepth: 1

   user_guide
   crappy


Indices and tables
==================

* :ref:`search`
* :ref:`genindex`



Lal300Sensor
==================================

.. automodule:: crappy.sensor._lal300Sensor
    :members:
    :undoc-members:

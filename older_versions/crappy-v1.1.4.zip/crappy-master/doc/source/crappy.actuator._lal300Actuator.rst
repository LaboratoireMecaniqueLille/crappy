Lal300Actuator
======================================

.. automodule:: crappy.actuator._lal300Actuator
    :members:
    :undoc-members:

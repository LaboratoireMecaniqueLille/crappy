Filter
===========================

.. automodule:: crappy.links._filter
    :members:

FakeCameraTechnical
============================================

.. automodule:: crappy.technical._fakeCameraTechnical
    :members:
    :undoc-members:

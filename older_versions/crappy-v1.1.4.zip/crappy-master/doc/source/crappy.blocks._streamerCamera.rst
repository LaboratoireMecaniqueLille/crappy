StreamerCamera
====================================

.. automodule:: crappy.blocks._streamerCamera
    :members:
    :show-inheritance:

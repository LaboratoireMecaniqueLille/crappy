SignalAdapter
===================================

.. automodule:: crappy.blocks._signalAdapter
    :members:
    :show-inheritance:

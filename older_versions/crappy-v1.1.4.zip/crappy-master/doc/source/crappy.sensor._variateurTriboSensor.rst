VariateurTriboSensor
==========================================

.. automodule:: crappy.sensor._variateurTriboSensor
    :members:
    :undoc-members:

Meta.acqSensor
====================================

.. automodule:: crappy.sensor._meta.acqSensor
    :members:
    :undoc-members:

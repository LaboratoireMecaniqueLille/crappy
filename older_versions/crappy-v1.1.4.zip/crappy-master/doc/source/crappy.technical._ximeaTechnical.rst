XimeaTechnical
=======================================

.. automodule:: crappy.technical._ximeaTechnical
    :members:
    :undoc-members:

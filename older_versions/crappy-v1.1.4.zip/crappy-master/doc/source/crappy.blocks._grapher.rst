Grapher
=============================

.. automodule:: crappy.blocks._grapher
    :members:
    :show-inheritance:

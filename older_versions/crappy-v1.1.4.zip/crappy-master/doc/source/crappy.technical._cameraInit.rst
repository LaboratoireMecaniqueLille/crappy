CameraInit
===================================

.. automodule:: crappy.technical._cameraInit
    :members:
    :undoc-members:

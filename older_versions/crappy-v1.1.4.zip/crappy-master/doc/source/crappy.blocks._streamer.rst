Streamer
==============================

.. automodule:: crappy.blocks._streamer
    :members:
    :show-inheritance:

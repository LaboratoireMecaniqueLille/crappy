JaiSensor
===============================

.. automodule:: crappy.sensor._jaiSensor
    :members:
    :undoc-members:
    :show-inheritance:
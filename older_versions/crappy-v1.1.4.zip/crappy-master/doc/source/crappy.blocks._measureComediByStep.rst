MeasureComediByStep
=========================================

.. automodule:: crappy.blocks._measureComediByStep
    :members:
    :show-inheritance:

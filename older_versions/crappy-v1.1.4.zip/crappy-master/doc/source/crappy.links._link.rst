Link
=========================

.. automodule:: crappy.links._link
    :members:

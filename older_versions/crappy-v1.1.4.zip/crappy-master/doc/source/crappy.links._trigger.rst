Trigger
============================

.. automodule:: crappy.links._trigger
    :members:

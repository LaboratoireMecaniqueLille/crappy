MultiPath
===============================

.. automodule:: crappy.blocks._multiPath
    :members:
    :show-inheritance:

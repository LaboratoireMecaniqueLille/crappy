DummySensor
=================================

.. automodule:: crappy.sensor._dummySensor
    :members:
    :undoc-members:

TechnicalCamera
========================================

.. automodule:: crappy.technical._technicalCamera
    :members:
    :undoc-members:

CommandTriboInterface
===========================================

.. automodule:: crappy.blocks._commandTriboInterface
    :members:
    :show-inheritance:

SignalGenerator
=====================================

.. automodule:: crappy.blocks._signalGenerator
    :members:
    :show-inheritance:

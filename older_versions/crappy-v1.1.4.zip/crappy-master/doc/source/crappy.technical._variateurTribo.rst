VariateurTribo
=======================================

.. automodule:: crappy.technical._variateurTribo
    :members:
    :undoc-members:

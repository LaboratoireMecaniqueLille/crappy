CommandComedi
===================================

.. automodule:: crappy.blocks._commandComedi
    :members:
    :show-inheritance:

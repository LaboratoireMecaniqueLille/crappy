FakeCommandBiaxe
======================================

.. automodule:: crappy.blocks._fakeCommandBiaxe
    :members:
    :show-inheritance:

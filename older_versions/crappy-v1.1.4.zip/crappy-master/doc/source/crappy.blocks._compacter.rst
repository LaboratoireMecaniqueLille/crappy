Compacter
===============================

.. automodule:: crappy.blocks._compacter
    :members:
    :show-inheritance:

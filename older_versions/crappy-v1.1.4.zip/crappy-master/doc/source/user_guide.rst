Crappy : User guide
===================

This guide is intended as an introductory overview of Crappy and explains 
how to use this module.

.. toctree::
    :maxdepth: 2

    intro
    basics


Niusb6008
===============================

.. automodule:: crappy.sensor._niusb6008
    :members:
    :undoc-members:

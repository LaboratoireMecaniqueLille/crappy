Lal300Command
===================================

.. automodule:: crappy.blocks._lal300Command
    :members:
    :show-inheritance:

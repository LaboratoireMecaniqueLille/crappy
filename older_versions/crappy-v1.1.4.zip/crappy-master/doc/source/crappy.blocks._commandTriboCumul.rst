CommandTriboCumul
=======================================

.. automodule:: crappy.blocks._commandTriboCumul
    :members:
    :show-inheritance:

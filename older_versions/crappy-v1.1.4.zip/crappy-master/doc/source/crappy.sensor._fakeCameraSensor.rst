FakeCameraSensor
======================================

.. automodule:: crappy.sensor._fakeCameraSensor
    :members:
    :undoc-members:

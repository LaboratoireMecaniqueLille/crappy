Reader
============================

.. automodule:: crappy.blocks._reader
    :members:
    :show-inheritance:

CommandTriboManual
========================================

.. automodule:: crappy.blocks._commandTriboManual
    :members:
    :show-inheritance:

VariateurTriboActuator
==============================================

.. automodule:: crappy.actuator._variateurTriboActuator
    :members:
    :undoc-members:

Crappy : Reference manual
=========================

This reference manual details functions, modules, and objects included 
in Crappy, describing what they are and what they do.

.. toctree::
    :maxdepth: 1

    crappy.actuator
    crappy.blocks
    crappy.links
    crappy.sensor
    crappy.technical

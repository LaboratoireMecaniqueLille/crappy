Meta
==========================

.. automodule:: crappy.blocks._meta
    :members:
    :show-inheritance:

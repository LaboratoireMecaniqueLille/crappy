Links objects
=============

Links are simply the part that carry information between the different blocks.
You just need to define the input and the output of a links, and it will 
transfer all data from one block to the other.
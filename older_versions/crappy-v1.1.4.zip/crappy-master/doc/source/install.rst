Installation
============

For now, the simplest way is to direclty get the last version on Github ::

    git clone https://github.com/LaboratoireMecaniqueLille/crappy.git
    cd crappy
    sudo python setup install

Note that for now, crappy as only been tested on ubuntu 14.04 and 15.10.
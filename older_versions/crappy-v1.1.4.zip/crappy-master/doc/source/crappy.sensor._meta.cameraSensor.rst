Meta.cameraSensor
=======================================

.. automodule:: crappy.sensor._meta.cameraSensor
    :members:
    :undoc-members:

MeasureAgilent34420A
==========================================

.. automodule:: crappy.blocks._measureAgilent34420A
    :members:
    :show-inheritance:
